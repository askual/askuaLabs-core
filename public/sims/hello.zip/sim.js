var winWidth = window.innerWidth;
var winHeight = window.innerHeight;
var game = new Phaser.Game(winWidth, winHeight, Phaser.AUTO,'simulationField');
var chall1State = { };
var menuState = { };

game.state.add('menu',menuState);
game.state.add('chall1',chall1State);
game.state.start('chall1');

